<?php

echo "</body>
</html>";
?>